import yourdfpy
import sys
from functools import partial
import trimesh
import ze
import numpy as np
from scipy.spatial.transform import Rotation as R
import pickle


zprint = partial(print, file=sys.stderr)

index = ze.args.key
zprint(index)