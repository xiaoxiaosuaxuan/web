import sys
from functools import partial
import trimesh
import ze
import yourdfpy
import numpy as np
from scipy.spatial.transform import Rotation as R
import pickle

zprint = partial(print, file=sys.stderr)


if __name__ == '__main__':
    urdf_prefix = "mano"
    urdf_path = "assets/MANO_urdf_new/mano_urdf (copy).urdf"
    mesh_dir = "assets/MANO_urdf_new/meshes"
    joint_cfg = ze.args.joint_cfg.asPrim()
    frame = ze.args.frame

    urdf = yourdfpy.URDF.load(urdf_path, force_mesh=True, mesh_dir=mesh_dir)
    robot = urdf.robot
    links = robot.links

    urdf_cfg = joint_cfg.verts.joint_cfg.to_numpy()
    urdf_cfg = list(urdf_cfg + urdf.cfg)
    scene = urdf.scene
    urdf.update_cfg(urdf_cfg)
    link_transforms = {link.name: scene.graph.get(
        link.name)[0] for link in links}
    r = R.from_rotvec((-75 / 180 * np.pi) * np.array([1, 0, 0]))
    model = r.as_matrix()
    translate = np.array([[0.3], [0.14], [0.3]])
    model = np.concatenate((model, translate), axis=1)
    model = np.concatenate((model, np.array([[0, 0, 0, 1]])))
    digit_size = 701

    for i, link in enumerate(links):
        prim = ze.ZenoPrimitiveObject.new()
        # digit codim target
        if link.name[:5] != "digit":
            prim = ze.ZenoPrimitiveObject.new()
            prim.points.resize(4)
            prim.points.add_attr("transform", (float, 4))
            prim.points.transform.from_numpy(model.dot(link_transforms[link.name]))
            ze.rets[f'{urdf_prefix}_{link.name}'] = prim
        
