import ze
import numpy as np
import yourdfpy

frame = ze.args.frame
joint_num = 15

joint_cfg = [0 for i in range(joint_num)]

for i in range(joint_num):
    joint_cfg[i] = 0.0001 * frame
    # if i == 2:
    #     joint_cfg[i] = -joint_cfg[i] * 0.5

joint_cfg = np.array(joint_cfg)
prim = ze.ZenoPrimitiveObject.new()
prim.verts.resize(joint_num)
prim.verts.add_attr('joint_cfg', (float, 1))
prim.verts.joint_cfg.from_numpy(joint_cfg)
ze.rets['joint_cfg'] = prim
ze.rets['frame'] = frame