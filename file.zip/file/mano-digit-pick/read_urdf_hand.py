import yourdfpy
import sys
from functools import partial
import trimesh
import ze
import numpy as np
from scipy.spatial.transform import Rotation as R
import pickle


zprint = partial(print, file=sys.stderr)

if __name__ == '__main__':
    urdf_prefix = "mano"
    urdf_path = "./assets/MANO_urdf_new/mano_urdf (copy).urdf"
    mesh_dir = "./assets/MANO_urdf_new/meshes"
    urdf = yourdfpy.URDF.load(urdf_path, force_mesh=True, mesh_dir=mesh_dir)
    robot = urdf.robot
    links = robot.links
    joints = robot.joints
    actuated_joints = urdf.actuated_joints


    zprint(f'[read_urdf] links: {[link.name for link in links]}')
    zprint(f'[read_urdf] actuated_joints: {[j.name for j in actuated_joints]}')
    zprint(f'num of actuated joints:{len(actuated_joints)}')
    zprint(f'num of links: {len(links)}')


    scene = urdf.scene
    link_mesh = {link.name: [] for link in links}
    for name in scene.graph.nodes_geometry:
        parent_name = scene.graph.transforms.parents[name]
        link_mesh[parent_name].append(scene.geometry[name])
    for link_name, geoms in link_mesh.items():
        result = trimesh.util.concatenate(geoms)
        if result == []:
            result = None
        link_mesh[link_name] = result


    link_transforms = {link.name: scene.graph.get(
        link.name)[0] for link in links}
    r = R.from_rotvec((-75 / 180 * np.pi) * np.array([1, 0, 0]))
    model = r.as_matrix()
    translate = np.array([[0.3], [0.14], [0.3]])
    model = np.concatenate((model, translate), axis=1)
    model = np.concatenate((model, np.array([[0, 0, 0, 1]])))
    for i, link in enumerate(links):
        prim = ze.ZenoPrimitiveObject.new()
        mesh = link_mesh[link.name]
        
        if not mesh or link.name[:5] == "digit":   # remove digit links
            continue
        
        verts = mesh.vertices
        prim.verts.resize(verts.shape[0])
        prim.verts.pos.from_numpy(verts)
        tris = mesh.faces
        prim.tris.resize(tris.shape[0])
        prim.tris.pos.from_numpy(tris)
        prim.points.resize(4)
        prim.points.add_attr("transform", (float, 4))
        prim.points.transform.from_numpy(model.dot(link_transforms[link.name]))
        # if i == 0:
        # 	zprint(f'init trans: {model.dot(link_transforms[link.name])}')
        zprint(f"{urdf_prefix}_{link.name}")
        ze.rets[f'{urdf_prefix}_{link.name}'] = prim
    
