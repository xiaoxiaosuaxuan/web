import yourdfpy
import sys
import ze
import numpy as np

vert_size = 701
urdf_prefix = "mano"

for i in range(1, 6):
    prim = ze.ZenoPrimitiveObject.new()
    prim.verts.resize(vert_size)
    prim.verts.add_attr("isBC", (int, 1)) 
    arr = np.ones(vert_size, dtype=int)
    prim.verts.isBC.from_numpy(arr)
    ze.rets[f"{urdf_prefix}_digit{i}"] = prim


