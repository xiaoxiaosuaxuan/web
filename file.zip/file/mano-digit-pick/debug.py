import yourdfpy
import sys
from functools import partial
import trimesh
#import ze
import numpy as np
from scipy.spatial.transform import Rotation as R



if __name__ == '__main__':
    urdf_prefix = "mano"
    urdf_path = "assets/MANO_urdf_new/mano_urdf.urdf"
    mesh_dir = "./assets/MANO_urdf_new/meshes"
    urdf = yourdfpy.URDF.load(urdf_path, force_mesh=True, mesh_dir=mesh_dir)
    urdf.show()
    robot = urdf.robot
    links = robot.links
    joints = robot.joints
    actuated_joints = urdf.actuated_joints

   
    cfg = {joints[0].name: 1}
    scene = urdf.scene
    link_mesh = {link.name: [] for link in links}
  
    
    
    verts = scene.geometry['mesh2.stl_1'].vertices
    ones = np.ones((verts.shape[0], 1))
    verts = np.concatenate((verts, ones), axis=1)
    trans = scene.graph.get('digit2')[0]
    verts = (trans @ verts.T).T[:, 0:3]
    
    
    for name in scene.graph.nodes_geometry:
        parent_name = scene.graph.transforms.parents[name]
        link_mesh[parent_name].append(scene.geometry[name])
        
    for link_name, geoms in link_mesh.items():
        result = trimesh.util.concatenate(geoms)
        if result == []:
            result = None
        link_mesh[link_name] = result
    # print(list(link_mesh.keys()))
    # print(type(link_mesh['m_avg_rthumb1']))

  
    # link_transforms = {link.name: scene.graph.get(
    #     link.name)[0] for link in links}

    # r = R.from_rotvec(np.pi * np.array([1, 0, 0]))
    # model = r.as_matrix()
    # translate = np.array([[0.3], [0.27], [0.3]])
    # model = np.concatenate((model, translate), axis=1)
    # model = np.concatenate((model, np.array([[0, 0, 0, 1]])))

